This is a swift clone of `examples/batched`.

$ `make`
$ `./batched_swift MODEL_PATH [PROMPT] [PARALLEL]`
